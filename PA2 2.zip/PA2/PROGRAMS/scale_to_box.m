function u = scale_to_box(a, a_min, a_max)

u = zeros(3,1);

u(1) = (a(1) - a_min(1))/(a_max(1)-a_min(1));
u(2) = (a(2) - a_min(2))/(a_max(2)-a_min(2));
u(3) = (a(3) - a_min(3))/(a_max(3)-a_min(3));


end
