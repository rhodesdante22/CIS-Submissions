close all
clear all

%this executable is a wrapper file, which is meant to run all the files
%together to save the user the time and effort of running each and file
%separately. As a result, this wrapper package will output both output
%files as well. 


%ensure directory specifications met
dir = string(split(pwd, '/'));
local = dir(end);
if (local=="PROGRAMS")
    cd ..
    addpath('OUTPUT/');
    cd PROGRAMS/
else
    disp("Please run script from the PROGRAMS directory for proper functionality")
    return
end
addpath('input');


%% user changeable parameters
testCase = 'a'; %change this letter to check a specific output
cases = 'debug'; %can be changed to 'debug' to check out debug cases instead



save('cases', 'cases');
save('testCase', 'testCase');

% start running code
PA2_1;

pause(1)

p_tip_OPT;

distortion_pivot_cal; %here we will get output file 1

clear all

pause(1)

EMtoCT_registration;

clear all

pause(1)

EM_navigation; %here we will get output file 2

