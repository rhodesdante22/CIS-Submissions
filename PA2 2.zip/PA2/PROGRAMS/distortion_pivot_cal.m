coeffs = load('coeffs');
coeffs = coeffs.coeffs;
letter = load('testCase');
letter = letter.testCase;
cases = load('cases');
cases = cases.cases;
empivot  = importdata(append('pa2-',cases,'-',letter,'-empivot.txt'));
data = empivot.data;
hdr = string(empivot.textdata);
hdr = double(hdr.split(","));
Nm = hdr(1); 
Nframe = hdr(2);

qmax = load('qmax');
qmax = qmax.qmax;
qmin = load('qmin');
qmin = qmin.qmin;

data = CorrectionDistortion(data, coeffs);

fr_mns = computeFrameMeans(data, Nm, Nframe);
G_0 = fr_mns(:,1);
Gis = data(:, 1:Nm);
gis = Gis - G_0;
save('gis', 'gis');
Rs_piv_cal = zeros(3*Nframe,3);
ps_piv_cal = zeros(3*Nframe,1);

%% Perform 3D to 3D rigid registration
for i=1:Nframe
    [Ri, p_i] = threedpointtopoint(transpose(gis), transpose(data(:, (i-1)*Nm + 1:i*Nm)));
    Rs_piv_cal(3*i-2:3*i, :) = Ri;
    ps_piv_cal(3*i-2:3*i, :) = p_i;
end
[p_tipEM, p_pivotEM] = pivCal(Rs_piv_cal, ps_piv_cal);
% p_pivot = CorrectionDistortion(transpose(p_pivot1), qmax, qmin, coeffs);
%% debugging
% output_EM  = importdata('pa2-debug-f-output1.txt');
% out_data = output_EM.data;
% p_pivot_debug = transpose(out_data(1,:));
% 
% abs(p_pivot_debug- p_pivotEM)
% (abs(p_pivot_debug- p_pivotEM)./p_pivot_debug)*100
save('p_tip', 'p_tipEM');
%the code above is to compare our final answer to the debug values to
%determine level of success


%generating output files 
cd ../OUTPUT/
file_name = append('pa2-',cases,'-',letter,'-output1.txt');
fid = fopen(file_name, 'wt');
fprintf(fid, '%d, %d, %s\n', Nc, size(Ci_expected,3) , file_name);
fprintf(fid, '  %.2f,   %.2f,   %.2f\n', p_pivotEM(1), p_pivotEM(2), p_pivotEM(3));
fprintf(fid, '  %.2f,   %.2f,   %.2f\n', p_pivotOPT(1), p_pivotOPT(2), p_pivotOPT(3));
for i=1:size(Ci_expected,3) 
    for j=1:size(Ci_expected,2) 
fprintf(fid, '  %.2f,   %.2f,   %.2f\n', Ci_expected(1,j,i), ...
    Ci_expected(2,j,i), Ci_expected(3,j,i));
    end
end

cd ../PROGRAMS/




