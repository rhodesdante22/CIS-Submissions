close all 
clear all

%this is a simple unit test to check the performance of our coeff_cal and
%CorrectionDistortion

A_expected = randi([-50, 50], [200,3]);
distortion = randi([-7, 7], [1,3]) * rand;

%the following loops are added because qmax and qmins of 0 produce NAN
%values in the calculation of the Bernstein coefficients. 
for l = 1:length(A_expected)
for i = 1:3


if A_expected(l,i) == 0
A_expected(l,i) = 1;

end
end
end


for j = 1:3


if distortion(j) == 0
distortion(j) = 1;

end
end


A_measured = A_expected.*distortion;

abc = transpose(CorrectionDistortion(A_measured, coeff_cal(A_measured, A_expected)));

A_expected-abc %this is nearly equal to 0. 



