function B_nk = Bern(N, k, v)

B_nk = nchoosek(N,k)*((1-v)^(N-k))*v^k;

end

