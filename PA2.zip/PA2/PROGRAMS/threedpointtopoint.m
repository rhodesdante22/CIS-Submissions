% Computes 3D point cloud to point cloud rigid registration from A to B 
% inputs:
% coords A, coords B = N by 3 matrix of points
% R,p gives frame transformation rotation and translation, respectively
% corresponding to F
function [R,p] = threedpointtopoint(coordsA,coordsB)


meanA = mean(coordsA);
meanB = mean(coordsB);

num_points = size(coordsA, 1);


At = zeros(num_points, 3);
Bt = zeros(num_points, 3);

for i = 1:num_points
At(i,:) = coordsA(i,:) - meanA;
Bt(i,:) = coordsB(i,:) - meanB;
end

% Use quaternion method to derive rotation matrix

% Compute H
H = zeros(3,3);
for ptNum=1:num_points
    for i=1:3
        for j=1:3
            H(i,j) = H(i,j) + At(ptNum, i)*Bt(ptNum, j);
        end
    end
end

%Compute G from H
G = zeros(4,4);
delta = [(H(2,3)-H(3,2)); (H(3,1)-H(1,3)); (H(1,2)-H(2,1))];
bottomQuad = H + transpose(H) -trace(H)*eye(3);
G = [trace(H), transpose(delta); delta, bottomQuad];

[V,D] = eig(G);

for i=1:4
    if D(i,i)==max(D, [], 'all')
        maxDex = i;
    end
end

unitQ = V(:, maxDex);

% extract R and p corresponding to the assumed frame transformation
R = quat2rotm(transpose(unitQ));
p = transpose(meanB) - R*transpose(meanA);
end

