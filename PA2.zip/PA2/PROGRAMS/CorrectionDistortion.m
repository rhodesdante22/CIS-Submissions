function expected = CorrectionDistortion(q, coeff)
%load in q_max, q_min
qmax = load('qmax');
qmax = qmax.qmax;
qmin = load('qmin');
qmin = qmin.qmin;

us = zeros(3, size(q,1));
 for i = 1:size(q,1)
     us(:, i) = scale_to_box(q(i, :), qmin, qmax);    
 end

F_mat = zeros(size(q,1), 6*6*6);
 
 for num = 1:size(q,1) 
     %0 to 5 for 5th order Bernstein polynomial
 for k = 0:5
     for j = 0:5
         for i = 0:5
                 
 F_ijk = Bern(5, i, us(1,num)) * Bern(5, j, us(2,num)) * Bern(5, k, us(3,num));
 
 F_mat(num, (i+(6*j)+(36*k) + 1)) = F_ijk;
         end
     end
 end
 end
 
expected = F_mat * coeff;
expected = transpose(expected);

end
