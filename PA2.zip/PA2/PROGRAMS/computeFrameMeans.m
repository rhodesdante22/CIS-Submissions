function fr_mns = computeFrameMeans(data, Nm, Nframe)
fr_mns = zeros(3, Nframe);
for i = 1:Nframe
fr_mns(:,i) = [mean(data(:,(i-1)*Nm +1:(i)*Nm), 2)];
end
end