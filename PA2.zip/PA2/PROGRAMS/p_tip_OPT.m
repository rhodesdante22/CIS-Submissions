%% Load, organize, initialize data for OPTICAL pivot calibration;

letter = load('testCase');
letter = letter.testCase;
addpath('input');
optpivot  = importdata(append('pa2-',cases,'-',letter,'-optpivot.txt'));
hdr = string(optpivot.textdata);
hdr = double(hdr.split(","));
opt_data = optpivot.data;
Nd = hdr(1); % Nd = Num EM tracker markers
Nh = hdr(2); % Nh = Num optical probe markers
Nframe_OPT = hdr(3);
djs = importdata(append('pa2-',cases,'-',letter,'-calbody.txt'));%dj
dj_data = djs.data;
dj = dj_data(1:Nd, :);

%% Compute Fd

% initialize Fds
Rdframes = zeros(3,3,Nframe_OPT);
pdframes = zeros(3,1,Nframe_OPT);
Ntot = Nh + Nd;
%Calculate Fds and Fd inverses
for i = 1:Nframe_OPT
    Dj = opt_data((i-1)*Ntot + 1:(i-1)*Ntot + Nd, :);
    [R, p] = threedpointtopoint(dj, Dj); 
    [Rdframes(:,:,i) ,pdframes(:,:,i)] = invOfF(R, p);
end



%% Perform 3D to 3D rigid registration

% prepare for pivot calibration
opt_data = transpose(opt_data);
refHis = opt_data(:, 1+Nd:Ntot);
H_0 = mean(refHis, 2);
hjs = refHis - H_0;
Fdinv_dot_hjs = F(Rdframes(:, : , 1), pdframes(:,:, 1), hjs);
Rs_opt_piv_cal = zeros(3*Nframe_OPT,3);
ps_opt_piv_cal = zeros(3*Nframe_OPT,1);

% execute pivot calibration
for i=1:Nframe_OPT
    transformed_data = F(Rdframes(:,:,i), pdframes(:,:, i), opt_data(:, (i-1)*Ntot+1+Nd:i*Ntot));   
    [Ri, p_i] = threedpointtopoint(transpose(Fdinv_dot_hjs),...
        transpose(transformed_data));
    Rs_opt_piv_cal(3*i-2:3*i, :) = Ri;
    ps_opt_piv_cal(3*i-2:3*i, :) = p_i;
end
[p_tipOPT, p_pivotOPT] = pivCal(Rs_opt_piv_cal, ps_opt_piv_cal); % in EM tracker coords



