%% Compute bj in EM tracker coordinates

% steps:
% 1. compute F_EMtoPointer at each fiducial given the Gis
% 2. compute the F_EMtoPointer dot p_tip to give the corresponding bj value
letter = load('testCase');
letter = letter.testCase;
cases = load('cases');
cases = cases.cases;
CTf = importdata(append('pa2-',cases,'-',letter,'-ct-fiducials.txt'));
EMf = importdata(append('pa2-',cases,'-',letter,'-em-fiducialss.txt'));
CTdata = CTf.data;
EMdata = EMf.data;
EMhdr = string(EMf.textdata);
EMhdr = double(EMhdr.split(","));
NG = EMhdr(1);
Nb = EMhdr(2);

% load the bjs
bjs = CTdata;

% Compute Bjs 
p_tip = load('p_tip');
p_tip = p_tip.p_tipEM;
coeffs = load('coeffs');
coeffs = coeffs.coeffs;
correctedEMdata = CorrectionDistortion(EMdata, coeffs);    

fr_mns = computeFrameMeans(correctedEMdata, NG, Nb);
gis = load('gis');
gis = gis.gis; % the residuals in the local probe coordinate frame
Gjs = correctedEMdata;
Bjs = zeros(Nb,3);

%% Compute Bj = F_EMtoTool * p_tip
for fr=1:Nb
    [R_EMtoTool, p_EMtoTool] = threedpointtopoint(transpose(gis), ...
        transpose(Gjs(:, (fr-1)*NG + 1:fr*NG)));
    Bjs(fr, :) = F(R_EMtoTool, p_EMtoTool, p_tip);
end
%% Compute Freg
[R_reg, p_reg] = threedpointtopoint(Bjs, bjs);
save('R_reg', 'R_reg')
save('p_reg', 'p_reg')
