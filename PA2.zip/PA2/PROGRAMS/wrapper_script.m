close all
clear all

%this executable is a wrapper file, which is meant to run all the files
%together to save the user the time and effort of running each and file
%separately. As a result, this wrapper package will output both output
%files as well. 

caseletters = ['a', 'b', 'c', 'd', 'e', 'f'];
unknowns = ['g', 'h', 'i', 'j'];
save('caseletters', 'caseletters')
save('unknowns', 'unknowns')
cases = 'debug'; % CHANGE THIS ('debug', 'unknown') to run desired loop 

addpath('input');


if strcmp(cases,'debug')
    num = 6;
else 
    num = 4;
end
save('num','num');

for ii = 1:num
    caseletters = load('caseletters');
    caseletters = caseletters.caseletters;
    unknowns = load('unknowns');
    unknowns = unknowns.unknowns; 
  

num = load('num');
num = num.num;
if num==6
testCase = caseletters(ii); 
else
testCase = unknowns(ii);
end

save('cases', 'cases');
save('testCase', 'testCase');
    

PA2_1;

pause(1)

p_tip_OPT;

distortion_pivot_cal; %here we will get output file 1

clear all

pause(1)

EMtoCT_registration;

clear all

pause(1)

EM_navigation; %here we will get output file 2

end
