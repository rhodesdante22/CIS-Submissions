close all 
clear all
 

%% Load data for distortion calibration;

letter = load('testCase');
letter = letter.testCase;
cases = load('cases');
cases = cases.cases;
A = importdata(append('pa2-',cases,'-',letter,'-calreadings.txt'));
B = importdata(append('pa2-',cases,'-',letter,'-calbody.txt'));

calRdgs = A.data;
calBdy = B.data;
hdr = string(A.textdata);
hdr = double(hdr.split(","));
Nd = hdr(1); % Number of optical markers on EM base
Na = hdr(2); % Number of optical markers on calibration object
Nc = hdr(3); % number of EM markers on calibration object
Nframe = hdr(4); % Number of frames

% initialize Fds and Fas
Rdframes = zeros(3,3,Nframe);
pdframes = zeros(3,1,Nframe);
Raframes = zeros(3,3,Nframe);
paframes = zeros(3,1,Nframe);


dj = calBdy(1:Nd, :);
aj = calBdy(Nd+1:Na+Nd, :);
cj = calBdy(1+Na+Nd:Na+Nd+Nc, :);

Nt = Na + Nc + Nd; %total number of elements in a frame
%% Compute Fd for each frame
for i = 1:Nframe
    Dj = calRdgs((i-1)*Nt + 1:(i-1)*Nt + Nd, :);
    [Rdframes(:,:,i) ,pdframes(:,:,i)] = threedpointtopoint(dj, Dj);
end

%% Compute Fa for each frame

for i = 1:Nframe
    Aj = calRdgs((i-1)*Nt + Nd + 1:(i-1)*Nt + Nd+Na, :);
    [Raframes(:,:,i) ,paframes(:,:,i)] = threedpointtopoint(aj, Aj);
end


%% Compute C_i_expected = Fd-1 Fa ci

Ci_expected = zeros(3,Nc, Nframe); % y dim represents all Ci for a given frame, z for across frames

for i=1:Nframe
    [RdInv, pdInv] = invOfF(Rdframes(:,:,i), pdframes(:,:,i));
    Ci_expected(:,:,i) = F(RdInv,pdInv,F(Raframes(:,:,i), paframes(:,:,i), transpose(cj)));
end

%% Compare C_i and C_i_expec

measured_Cjs = zeros(3, Nc, Nframe);
for i=1:Nframe
    measured_Cjs(:,:,i) = transpose(calRdgs((i-1)*Nt + Nd +Na + 1:(i-1)*Nt + Nd + Na + Nc, :));
end


%% prepare for distortion correction

%reshape was giving us issues. Manually reshape calculated and expected
c_expected = zeros(Nframe*Nc, 3);
c_measured = zeros(Nframe*Nc, 3);
for i = 1:Nframe
    c_expected(Nc*(i-1)+1:Nc*i,:) = transpose(Ci_expected(:, :, i)); 
    c_measured(Nc*(i-1)+1:Nc*i,:) = transpose(measured_Cjs(:, :, i)); 
end


% apply correction distortion
corrected = transpose(CorrectionDistortion(c_measured, coeff_cal(c_measured, c_expected)));