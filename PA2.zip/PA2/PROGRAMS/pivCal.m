function [pt, pp] = pivCal(Rs, ps)
%create memory and performing data reshaping; overhead
N = length(ps)/3;
A = zeros(3*N, 6);

% create a [3N, 3] matrix of 3x3 negative identity matrices
negEyes = zeros(3*N, 3);
for i=1:N
    negEyes((3*i-2:3*i), :) = -1*eye(3);
end

%construct A for Ax=b problem
A(:, 1:3) = Rs;
A(:, 4:6) = negEyes;

%solve Ax=b problem using linsolve and decompose output into pt and pp
twoVecs = linsolve(A, -ps);
pt = twoVecs(1:3);
pp = twoVecs(4:6);
end