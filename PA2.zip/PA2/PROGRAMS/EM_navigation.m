%% Computation of EM_NAV

% steps:
% 1. apply distortion correction to the Gi values
% 2. compute pointer tip coordinates with respect to tracker base
% 3. Apply Freg*pointer tip = bj to find the new point in CT space

% Load in the data
letter = load('testCase');
letter = letter.testCase;
cases = load('cases');
cases = cases.cases;
EM_nav = importdata(append('pa2-',cases,'-',letter,'-EM-nav.txt'));
EMnavdata = EM_nav.data;
EMnavhdr = string(EM_nav.textdata);
EMnavhdr = double(EMnavhdr.split(","));
NG = EMnavhdr(1); % num markers on probe
Nframe = EMnavhdr(2); 

%% apply distortion correction to the Gi values

coeffs = load('coeffs');
coeffs = coeffs.coeffs;

R_reg = load('R_reg');
R_reg = R_reg.R_reg;

p_reg = load('p_reg');
p_reg = p_reg.p_reg;

gis = load('gis');
gis = gis.gis; % the residuals in the local probe coordinate frame
p_tip = load('p_tip');
p_tip = p_tip.p_tipEM;

correctedNavdata = transpose(CorrectionDistortion(EMnavdata, coeffs));
%% compute pointer tip coordinates with respect to tracker base

Bjs_nav = zeros(Nframe, 3);
for fr=1:Nframe
    [R_EMtoTool, p_EMtoTool] = threedpointtopoint(transpose(gis), ...
        EMnavdata((fr-1)*NG + 1:fr*NG, :));
    Bjs_nav(fr, :) = F(R_EMtoTool, p_EMtoTool, p_tip);
end

%% Apply Freg*Bj = bj to find the new point in CT space

bj_nav = zeros(Nframe, 3);
for fr_num = 1:Nframe
    bj_nav(fr_num, :) = transpose(F(R_reg, p_reg, transpose(Bjs_nav(fr_num, :))));
end

% Check ours against theirs
% debug = importdata();
% debugdata = debug.data;
% diffs  = bj_nav - debugdata;
% 
% for i = 1:length(bj_nav)
% 
% percent_diff(i,:) = (diffs(i,:)./(debugdata(i,:))) * 100; %getting the
% % percentage differnce as a metric to deteremine success
% end

%% Writing outputs to txt files
file_name = append('pa2-',cases,'-',letter,'-output2.txt');
fid = fopen(file_name, 'wt');
fprintf(fid, '%d, %s\n', Nframe, file_name);
for i=1:size(bj_nav,1) 
fprintf(fid, '  %.2f,   %.2f,   %.2f\n', bj_nav(i,1), ...
    bj_nav(i,2), bj_nav(i,3));
end