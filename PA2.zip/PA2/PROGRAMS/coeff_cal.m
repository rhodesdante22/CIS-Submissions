function coeffs  = coeff_cal(c_measured, c_expected)
% calculate qmax and qmin
qmax = max(c_measured); 
qmin = min(c_measured);
save('qmax', 'qmax')
save('qmin', 'qmin')

% calculate us
us = zeros(3, length(c_measured));
for i = 1:length(c_measured)
     us(:, i) = scale_to_box(c_measured(i,:), qmin, qmax);
end

F_mat = zeros(length(us), 6*6*6);
 
 for num = 1:length(us)
 for k = 0:5
     for j = 0:5
         for i = 0:5            
 F_ijk = Bern(5, i, us(1,num)) * Bern(5, j, us(2,num)) * Bern(5, k, us(3,num));
 F_mat(num, i+6*j+36*k + 1) = F_ijk;
         end
     end
 end
 end
 
 cx = linsolve(F_mat,(c_expected(:,1)));
 cy = linsolve(F_mat, (c_expected(:,2)));
 cz = linsolve(F_mat, (c_expected(:,3)));
 coeffs = [cx, cy, cz];
save('coeffs', 'coeffs');
end
