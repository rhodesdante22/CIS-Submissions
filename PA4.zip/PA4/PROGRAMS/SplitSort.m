function [n1struct, n2struct, n3struct, n4struct, ...
    n5struct, n6struct, n7struct, n8struct] = SplitSort(center, triList, numTri)
%this function 
%structure will contain number of triangles and their indices

%initialize empty vectors
n1struct = zeros(1,numTri);
n2struct = zeros(1,numTri);
n3struct = zeros(1,numTri);
n4struct = zeros(1,numTri);
n5struct = zeros(1,numTri);
n6struct = zeros(1,numTri);
n7struct = zeros(1,numTri);
n8struct = zeros(1,numTri);


%marking each triangle according to which quadrant it belongs to
for i=1:numTri %for all the number of triangles
    triangle = triList(i);
    if triangle.sortPt(1) > center(1) %check the x coordinate
        if triangle.sortPt(2) > center(2)%check the y coordinate
            if triangle.sortPt(3) > center(3) %check the z coordinate
                n1struct(1) = n1struct(1) + 1;
                n1struct(n1struct(1)+1) = i;
            else    %XYz
                n2struct(1) = n2struct(1) + 1;
                n2struct(n2struct(1)+1) = i;
            end
        else
            if triangle.sortPt(3) > center(3) %XyZ
                n3struct(1) = n3struct(1) + 1;
                n3struct(n3struct(1)+1) = i;
            else    %Xyz
                n4struct(1) = n4struct(1) + 1;
                n4struct(n4struct(1)+1) = i;
            end
        end

    else
        if triangle.sortPt(2) > center(2)
            if triangle.sortPt(3) > center(3) %xYZ
                n5struct(1) = n5struct(1) + 1;
                n5struct(n5struct(1)+1) = i;
            else    %xYz
                n6struct(1) = n6struct(1) + 1;
                n6struct(n6struct(1)+1) = i;
            end
        else
            if triangle.sortPt(3) > center(3) %xyZ
                n7struct(1) = n7struct(1) + 1;
                n7struct(n7struct(1)+1) = i;
            else    %xyz
                n8struct(1) = n8struct(1) + 1;
                n8struct(n8struct(1)+1) = i;
            end
        end

    end

end
end