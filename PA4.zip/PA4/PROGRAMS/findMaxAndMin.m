function [LB, UB] = findMaxAndMin(triList, numTri)
% Helper function to find bounding box corners

storage = zeros(3*numTri, 3);
for tr = 1:numTri
    triangle = triList(tr);
    storage(3*tr-2, :) = triangle.vert1;
    storage(3*tr-1, :) = triangle.vert2;
    storage(3*tr, :) = triangle.vert3;
end
LB = min(storage);
UB = max(storage);
end