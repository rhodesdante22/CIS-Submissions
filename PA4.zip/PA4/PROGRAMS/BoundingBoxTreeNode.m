classdef BoundingBoxTreeNode
    % A rectangular box octree node to improve search speed

    properties
        center;
        upperB;
        lowerB;
        numTriangles;
        SubTrees; 
        triangleList;
    end

    methods
        function treeNode = BoundingBoxTreeNode(triList,numTri)
            % Constructor
            treeNode.numTriangles = numTri;
            treeNode.triangleList = triList;
            [treeNode.lowerB, treeNode.upperB] = findMaxAndMin(triList, numTri);
            treeNode.center = mean([treeNode.lowerB; treeNode.upperB]);
            treeNode.SubTrees = constructSubtrees(numTri,treeNode);
        end

        function subtrees = constructSubtrees(numTriangles,bBoxTNode)
            % base case
            %if number of trianges <= 5, just do a linear search
            if (numTriangles <= 5 || ...   %determine parameters empircally
                    norm(bBoxTNode.upperB-bBoxTNode.lowerB) <= 10)
                subtrees = bBoxTNode; 
                return;
            end

            %split triangles, initialize subtrees, put triangles in subtrees
            [nst1,nst2,nst3,nst4,nst5,nst6,nst7,nst8] = SplitSort(bBoxTNode.center,...
                bBoxTNode.triangleList, bBoxTNode.numTriangles);
            bBoxTNode.SubTrees = bBoxTNode.empty(8, 0);
            Sts = [nst1;nst2;nst3;nst4;nst5;nst6;nst7;nst8];
            
            for tree = 1:8
                temp = Sts(tree,:);
                localNumTri = temp(1);
                lclTLst = Triangle.empty(localNumTri, 0);
                for tri = 2:localNumTri+1
                    if(localNumTri==0)
                        break;
                    end
                    triDex = temp(tri);
                    lclTLst(tri-1) = bBoxTNode.triangleList(triDex);
                end
                bBoxTNode.SubTrees(tree) = BoundingBoxTreeNode(lclTLst, localNumTri); %run for each subtree
            end   
            subtrees = bBoxTNode.SubTrees;
        end

        % determine if the node has (valid) subtrees
        function haveTrees = haveSubtrees(bbtnode)
            haveTrees = 0;
            if length(bbtnode.SubTrees)>1
                haveTrees = 1;
            end
        end
    end
end