%% Obtain directory info
dir =  split(string(pwd), "/");
subdir = dir(end);
if ~strcmp(subdir,"PROGRAMS")
    error('script must be run from the "PROGRAMS" subdirectory');
end
addpath("../OUTPUT/");

%% Construct large data structures 
%construct list of triangles
probNum = '4';
[triList, Ntri] = constructTriList(probNum);

% construct octree
octTree = BoundingBoxTreeNode(triList,Ntri);

%% Perform ICP

debugLetters = ['A','B','C','D','E','F'];
unknownLetters = ['G','H','J', 'K'];

for i = 1:10
if i<7
    casetype = 'Debug';
    Pletter = debugLetters(i);
else
    casetype = 'Unknown';
    Pletter = unknownLetters(i-6);
end

% Print letter of iteration
disp(append("Beginning calculation of case ", Pletter));

% s_ks = Freg * d_ks
% c_k = closest points to the s_ks that lie on the mesh
d_ks = calcPointerCoordsinRBFrame(probNum, Pletter, casetype); 
c_ks = zeros(size(d_ks));
Nframes = size(c_ks,1);


% initial guess: F_reg = I
R_reg = eye(3);
p_reg = zeros(3,1);

% to terminate loop
nrms = [inf,inf,inf];
% MIN_CNSRT = 0.1;
% constraint = 2;

% Terminate when subsequent iterations produce neglibible differences
while (~(abs(nrms(1)-nrms(2))<.005 && abs(nrms(2)-nrms(3))<.005)) 
    s_ks = transpose(F(R_reg, p_reg, transpose(d_ks)));

    % compute closest points to sample points
    for j = 1:Nframes
        [closeness,c_ks(j,:)] = octreeSearch(s_ks(j,:), inf, [inf,inf,inf], octTree);
    end

    %shift previous attempts
    nrms(3) = nrms(2);
    nrms(2) = nrms(1);
    nrms(1) = norm(c_ks-s_ks);

    % for debugging
    disp("give closeness metrics");
    disp(nrms);

%     
%     % outlier rejection. Improve efficiency!!
%     weights = zeros(Nframes, 1);
%     for j = 1:size(c_ks,1)
%         if norm(c_ks(j,:)-s_ks(j,:)) < constraint
%             weights(j) = 1;
%         end
%     end
% 
%     [d_rels, c_rels] = extractRelevants(weights, d_ks, c_ks);

    % compute F_reg guess
    [R_reg, p_reg] = threedpointtopoint(d_ks, c_ks);

%     if constraint > 0.1
%         constraint = constraint - 0.1;
%     end

end

%generating output files 
file_name = append('../OUTPUT/pa4-',Pletter,'-Output.txt');
fid = fopen(file_name, 'wt');

fprintf(fid, '%d, %s\n', Nframes, append('pa4-',Pletter,'-Output.txt'));
for j=1:Nframes 
fprintf(fid, '%.2f\t%.2f\t%.2f\t\t%.2f\t%.2f\t%.2f\t%.3f\n',...
    s_ks(j,1),s_ks(j,2),s_ks(j,3),c_ks(j,1),c_ks(j,2),c_ks(j,3),norm(s_ks(j,:)-c_ks(j,:)));
end

end




