function [bnd, closestPt] = octreeSearch(point, bound, currentClosest, node)
%base cases

if isempty(node.upperB) % redundant/invalid node; do nothing
    closestPt = currentClosest;
    bnd = bound;
    return;
end
if point(1)> node.upperB(1) + bound  || point(1)< node.lowerB(1) - bound 
    closestPt = currentClosest;
    bnd = bound;
    return 
end
if point(2)> node.upperB(2) + bound  || point(2)<node.lowerB(2) - bound 
    closestPt = currentClosest;
    bnd = bound;
    return 
end
if point(3)> node.upperB(3) + bound  || point(3)< node.lowerB(3) - bound 
    closestPt = currentClosest;
    bnd = bound;
    return 
end

%this is a recursive call of the function
if haveSubtrees(node) 
   
    [bnd, closestPt] = octreeSearch(point, bound, currentClosest, node.SubTrees(1));
    [bnd, closestPt] = octreeSearch(point, bnd, closestPt, node.SubTrees(2));
    [bnd, closestPt] = octreeSearch(point, bnd, closestPt, node.SubTrees(3));
    [bnd, closestPt] = octreeSearch(point, bnd, closestPt, node.SubTrees(4));
    [bnd, closestPt] = octreeSearch(point, bnd, closestPt, node.SubTrees(5));
    [bnd, closestPt] = octreeSearch(point, bnd, closestPt, node.SubTrees(6));
    [bnd, closestPt] = octreeSearch(point, bnd, closestPt, node.SubTrees(7));
    [bnd, closestPt] = octreeSearch(point, bnd, closestPt, node.SubTrees(8));

else
    %when there is no further subtrees, execute else
    tList = node.triangleList;
    nTri = node.numTriangles;
    for i=1:nTri
        [bnd, closestPt] = updateClosest(tList(i),point,bound,currentClosest);
        currentClosest = closestPt;
        bound = bnd;
    end
end