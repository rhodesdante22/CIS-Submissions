function clsPt = findClosestPt(point, p,q,r) 

% solve least squares problem for lambda and mu
v1 = q-p;
v2 = r-p;
v3 = point-p;

A = [v1 v2];

% moore penrose pseudo inverse solves for lambda and mu explicitly
eta = inv(transpose(A)*A)*transpose(A)*v3;
lambda = eta(1);
mu = eta(2);

% compute theoretical closest point on triangle
c = p + lambda*(q-p) +mu*(r-p);

if(mu>=0 && lambda>=0 && mu+lambda<=1) % point can be projected onto triangle surface
    clsPt = c;
else  % point cannot be projected onto surface; project onto edge
   if mu<0
       clsPt = projectOnSegment(c,p,q);
   elseif lambda<0
       clsPt = projectOnSegment(c,r,p);
   else
       clsPt = projectOnSegment(c,q,r);
   end
end