function coords = F(R,p, inputCoords) %matrix R, col vector p, col vectors input coords
coords = R*(inputCoords) + p;
end

