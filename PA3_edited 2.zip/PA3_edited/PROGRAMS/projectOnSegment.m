function clsPt = projectOnSegment(c, vert1, vert2)
% project point c onto the segment defined by vert1, vert2
lam = dot(c-vert1, vert2-vert1)/dot(vert2-vert1, vert2-vert1);
lam_seg = max(0,min(lam, 1));
clsPt = vert1 + lam_seg*(vert2-vert1);
end