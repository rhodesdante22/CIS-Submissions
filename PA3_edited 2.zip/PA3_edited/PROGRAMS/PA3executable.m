%% This is the executable for PA3
%% Obtain directory info
dir =  split(string(pwd), "/");
subdir = dir(end);
if ~strcmp(subdir,"PROGRAMS")
    error('script must be run from the "PROGRAMS" subdirectory');
end
addpath("../OUTPUT/");

%% Construct large data structures 
%construct list of triangles
probNum = '3';
[triList, Ntri] = constructTriList(probNum);

% construct octree
octTree = BoundingBoxTreeNode(triList,Ntri);

%% Loop over cases and write output files
debugLetters = ['A','B','C','D','E','F'];
unknownLetters = ['G','H','J'];

diff = 0;
for i = 1:9
if i<7
    casetype = 'Debug';
    Pletter = debugLetters(i);
else
    casetype = 'Unknown';
    Pletter = unknownLetters(i-6);
end

d_ks = calcPointerCoordsinRBFrame(probNum, Pletter, casetype); %define casetype

c_klinearSearch = zeros(size(d_ks));
c_k = zeros(size(d_ks));
% disp("computing octree search:")
tic

Nframes = size(c_k,1);
for j = 1:Nframes
    [closeness,c_k(j,:)] = octreeSearch(d_ks(j,:), inf, [inf,inf,inf], octTree);
end
oc_tree_time(i) = toc;

% disp("computing linear search:")
tic
for j = 1:Nframes
    c_klinearSearch(j,:) = triLinSearch(d_ks(j,:), triList);
end
linear_time(i) = toc;

%Check that linear search and octree search provide same results
if(norm(c_klinearSearch-c_k))
    diff = 1;
end

%generating output files 
file_name = append('../OUTPUT/pa3-',Pletter,'-Output.txt');
fid = fopen(file_name, 'wt');

fprintf(fid, '%d, %s\n', Nframes, append('pa3-',Pletter,'-Output.txt'));
for j=1:Nframes 
fprintf(fid, '%.2f\t%.2f\t%.2f\t\t%.2f\t%.2f\t%.2f\t%.3f\n',...
    d_ks(j,1),d_ks(j,2),d_ks(j,3),c_k(j,1),c_k(j,2),c_k(j,3),norm(d_ks(j,:)-c_k(j,:)));
end
end
if diff
    disp("Discrepancy between linear and octree searches")
else
    disp("No discrepancy between linear and octree searches")
end
%getting the calculation for the time differences between the two searches
lin_time = transpose(linear_time)
oc_time = transpose(oc_tree_time)
time_difference = transpose(linear_time) - transpose(oc_tree_time)






