function [final_bound, closestPt] = updateClosest(triangle, point, bound, currentClosest)
%function to update the closes point 
closestPt = transpose(fndClst2Tri(triangle, point));
dist = norm(point-closestPt); %euciledian distance
if (dist<bound)
     final_bound = dist; 
else
    final_bound = bound;
    closestPt = currentClosest;
end
end