function d_ks = calcPointerCoordsinRBFrame(probNum, Pletter, casetype)
%% Input body files
addpath('input');
ABody = importdata(append('Problem', probNum, '-BodyA.txt'));
BBody = importdata(append('Problem', probNum, '-BodyB.txt'));
Ahdr = string(ABody.textdata);
Ahdr = double(Ahdr.split());
NaMrk = Ahdr(1); % Number of LED markers on A body
Bhdr = string(BBody.textdata);
Bhdr = double(Bhdr.split());
NbMrk = Bhdr(1); % Number of LED markers on A body

% parse body files to acquire LED marker locations and tip in rigid body coords
Amrks = ABody.data(1:end-1,:);
Bmrks = BBody.data(1:end-1,:);
Atip = ABody.data(end,:);


%% Input tracker information

trkrRdgs = importdata(append("PA",probNum,"-",Pletter, "-",casetype,"-SampleReadingsTest.txt"));
Thdr = double(string(trkrRdgs.textdata));
Ns = Thdr(1);
Nframes = Thdr(2);
trkrData = trkrRdgs.data;

as = zeros(NaMrk*Nframes,3);
bs = zeros(NaMrk*Nframes,3);
% Gather a and b readings
for frame = 0:Nframes-1
    as(1+frame*NaMrk:(frame+1)*NaMrk,:) = trkrData(1+Ns*frame:Ns*frame + NaMrk, :);
    bs(1+frame*NbMrk:(frame+1)*NbMrk,:) = trkrData(1+Ns*frame+NaMrk:Ns*frame + NaMrk +NbMrk, :);
end

%% Compute frame transformation between as and As, bs and Bs

Rk_a = zeros(3*Nframes, 3);
pk_a = zeros(Nframes, 3);
Rk_b = zeros(3*Nframes, 3);
pk_b = zeros(Nframes, 3);

% Find Fk_a, Fk_b from tracker to rigid body
for fr = 0:Nframes-1
    [Rk_a(3*fr+1:3*(fr+1),:), pk_a(fr+1,:)] = threedpointtopoint(Amrks,as(1+fr*NaMrk:(fr+1)*NaMrk, :));
    [Rk_b(3*fr+1:3*(fr+1),:), pk_b(fr+1,:)] = threedpointtopoint(Bmrks, bs(1+fr*NbMrk:(fr+1)*NbMrk, :));
end


%% Compute the d_k as Fb-1 * Fa * Atip

d_ks = zeros(size(pk_a));
for i = 1:Nframes
    [Rbinv, pbinv] = invOfF(Rk_b(3*i-2:3*i, :), transpose(pk_b(i, :)));
    d_ks(i, :) = F(Rbinv, pbinv, ...
        F(Rk_a(3*i-2:3*i, :), transpose(pk_a(i,:)), transpose(Atip))); 
    % transpose bc F, invofF require column vector input
end

end



