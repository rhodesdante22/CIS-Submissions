% Run this to check results after implementing
% used to gauge closeness to correct outputs


%% Obtain directory info
dir =  split(string(pwd), "/");
subdir = dir(end);
if ~strcmp(subdir,"PROGRAMS")
    error('script must be run from the "PROGRAMS" subdirectory');
end
addpath('input');

%% Construct large data structures 
%construct list of triangles
probNum = '3';
[triList, Ntri] = constructTriList(probNum);

% construct octree
octTree = BoundingBoxTreeNode(triList,Ntri);

%% Loop over cases
debugLetters = ['A','B','C','D','E','F'];
probNum = '3';

for i = 1:6
    Pletter = debugLetters(i);
    d_ks = calcPointerCoordsinRBFrame(probNum, Pletter, 'debug');
    c_k = zeros(size(d_ks));
    Nframes = size(c_k,1);
    for j = 1:Nframes
        [closeness,c_k(j,:)] = octreeSearch(d_ks(j,:), inf, [inf,inf,inf], octTree);
    end


debugInfo = importdata(append('input/PA', probNum, '-', Pletter,'-Debug-Answer.txt'), " ", 1);
debugData = debugInfo.data;


% get the difference between the values we computed and the values that
% were given to us
disp(append("Case ", Pletter));
disp('Difference between calculated and expected pointer positions');
disp(d_ks-debugData(:, 1:3));
disp('Difference between calculated and expected closest points');
disp(c_k-debugData(:, 4:6));
end
