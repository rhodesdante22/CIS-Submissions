function clstPt = triLinSearch(point,triList)
    clstPt = [inf,inf,inf]; %this is the intial estimation of the search box
    bestDist = inf;
    for triNum = 1:length(triList)
        tri = triList(triNum);
        currentPt = transpose(fndClst2Tri(tri, point));
        if norm(currentPt-point) < bestDist
            clstPt = currentPt; %update closest point from infinity to current point
            bestDist = norm(currentPt-point); %update distance from infinity to new value
        end
    end
end