classdef Triangle
    properties
        vert1; %vertices are in CT coordinates
        vert2;
        vert3;
        sortPt;
    end

    methods
        function tri = Triangle(v1,v2,v3) % triangle constructor
            tri.vert1 = v1;
            tri.vert2 = v2;
            tri.vert3 = v3;
            tri.sortPt = mean([v1;v2;v3]);
        end

        function closestPt = fndClst2Tri(tri, a)
            % use findClosestPoint function to find the closest point on the triangle
            closestPt = findClosestPt(transpose(a), transpose(tri.vert1), ...
                transpose(tri.vert2), transpose(tri.vert3));
            % recall findClosestPoint requires column vec input, hence
            % transposition
        end
    end
end