% Debug of the find closest point method for randomly generated data
% on a general, but easy to understand example

% Create simple triangle
t = Triangle([0,5,0], [5,0,0], [0,0,0]);

% Generate random points in a reasonable distribution around the triangle
a = 10* rand(500, 3)-3;

correct = 1;
counts = zeros(1,7); %ensure all cases have been checked
for i=1:500
    projectIn = (a(i,1)>=0 && a(i,1)<=5) && (a(i,2)>=0 && a(i,2)<=5) ...
        && (a(i,2)<=5-a(i,1));
    if projectIn
        counts(1) = counts(1)+1; %ensure all cases have been checked
        if sum(round([a(i, 1) a(i,2), 0]-transpose(fndClst2Tri(t, a(i,:))), 8)) 
            %if difference between projected point and expected value for
            %that point
            correct = 0;  
        end
    elseif (a(i,2)>=0 && a(i,2)<=5) && a(i,1)<=0 
        counts(2) = counts(2)+1; %ensure all cases have been checked
        % to the left edge, within Y bounds to not be on vertex
        if sum(round([0, a(i, 2), 0] - transpose(fndClst2Tri(t, a(i,:))),8))
            correct = 0;          
        end
    elseif (a(i,1)>=0 && a(i,1)<=5) && a(i,2)<=0 
        counts(3) = counts(3)+1; %ensure all cases have been checked
        % to the bottom edge, within X bounds to not be on vertex
        if sum(round([a(i, 1), 0, 0] - transpose(fndClst2Tri(t, a(i,:))),8))
            correct = 0;
        end
    elseif (a(i,1)<0 && a(i,2)<0)
        counts(4) = counts(4)+1; %ensure all cases have been checked
        if sum(round([0, 0, 0] - transpose(fndClst2Tri(t, a(i,:))),8))
            % project onto bottom left vertex
            correct = 0;
        end        
    elseif (a(i,1)<0 && a(i,2)>5)
        counts(5) = counts(5)+1; %ensure all cases have been checked
        if sum(round([0, 5, 0] - transpose(fndClst2Tri(t, a(i,:))),8))
            % project onto top left vertex
            correct = 0;
        end      
    elseif (a(i,1)<5 && a(i,2)>0)
        counts(6) = counts(6)+1; %ensure all cases have been checked
        if sum(round([5, 0, 0] - transpose(fndClst2Tri(t, a(i,:))),8))
            % project onto rightmost vertex
            correct = 0;
        end 
    else
        counts(7) = counts(7) + 1;
        c = transpose(fndClst2Tri(t, a(i,:)));
        cprime = projectOnSegment([a(i,1), a(i,2), 0], [0,5,0], [5,0,0]);
        if ~(all(round(c,8)==round(cprime,8)) && (round(c(1)+c(2),8)==5)) 
            % first check: projectOnSegment and full findClosestPoint
            % methods produce the same point
            % second check: projected point lies on the hypotenuse of
            % triangle
            correct = 0;     
        end
    end  
end

if ~correct || ~all(counts) || sum(counts) ~= 500 %three conditions to check if our unit test pases
    disp("unit test fails");
else
    disp("unit test passes");
end

