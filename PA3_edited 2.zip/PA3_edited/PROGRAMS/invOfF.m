function [Rinv, minusRinvP] = invOfF (R, p)
Rinv = inv(R);
minusRinvP = -1*inv(R)*p;
end