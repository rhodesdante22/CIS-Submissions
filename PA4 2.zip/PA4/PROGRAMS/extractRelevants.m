function [d_rels, c_rels] = extractRelevants(weights, samplePts, meshPts)
d_rels = zeros(sum(weights), 3);
c_rels = zeros(sum(weights), 3);
dex = 1;
for i = 1:length(weights)   
    if weights(i)
        d_rels(dex,:) = samplePts(i,:);
        c_rels(dex,:) = meshPts(i,:);
        dex = dex+1;
    end
end
end