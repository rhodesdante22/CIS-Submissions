close all
clear all
%% Obtain directory info
dir =  split(string(pwd), "/");
subdir = dir(end);
if ~strcmp(subdir,"PROGRAMS")
    error('script must be run from the "PROGRAMS" subdirectory');
end
addpath("../OUTPUT/");

%% Construct large data structures
%construct list of triangles
probNum = '4';
[triList, Ntri] = constructTriList(probNum);

% construct octree
octTree = BoundingBoxTreeNode(triList,Ntri);

%% Perform ICP

% Print letter of iteration
casetype = 'Debug';
Pletter = 'B';

% c_k = closest points to the s_ks that lie on the mesh
d_ks = calcPointerCoordsinRBFrame(probNum, Pletter, casetype);

%the following lines are used to produce 20 random points 
mean_d_ks = [mean(d_ks(:,1)), mean(d_ks(:,2)), mean(d_ks(:,3))];
std_d_ks = [std(d_ks(:,1)), std(d_ks(:,2)), std(d_ks(:,3))];

a = [mean_d_ks(1) - std_d_ks(1), mean_d_ks(2) - std_d_ks(2) , mean_d_ks(3) - std_d_ks(3)];
b = [mean_d_ks(1) + std_d_ks(1), mean_d_ks(2) + std_d_ks(2) , mean_d_ks(3) + std_d_ks(3)];

%points produced lie within one std of the mean of all points
%this is done separately for the x, y, and z
rand_d_ks = [a(1) + (b(1)-a(1)).*rand(20,1),a(2) + (b(2)-a(2)).*rand(20,1),a(3) + (b(3)-a(3)).*rand(20,1)] ;

%append points to bottom of d_ks array
d_ks = [d_ks;rand_d_ks];

c_ks = zeros(size(d_ks));
Nframes = size(c_ks,1);

% initial guess: F_reg = I
R_reg = eye(3);
p_reg = zeros(3,1);

% to terminate loop
nrms = [inf,inf,inf];

counter = 0;
% Terminate when subsequent iterations produce neglibible differences
while (~(abs(nrms(1)-nrms(2))<.005 && abs(nrms(2)-nrms(3))<.005))
    s_ks = transpose(F(R_reg, p_reg, transpose(d_ks)));
    
    % compute closest points to sample points
    for j = 1:Nframes
        [closeness,c_ks(j,:)] = octreeSearch(s_ks(j,:), inf, [inf,inf,inf], octTree);
    end
    
    %shift previous attempts
    nrms(3) = nrms(2);
    nrms(2) = nrms(1);
    nrms(1) = norm(c_ks-s_ks);
    
 % outlier rejection
    weights = zeros(Nframes, 1);
    for j = 1:size(c_ks,1)
        if norm(c_ks(j,:)-s_ks(j,:)) < 0.3 
            weights(j) = 1;
        end
    end
    
    [d_rels, c_rels] = extractRelevants(weights, d_ks, c_ks);

    % compute F_reg guess
    [R_reg, p_reg] = threedpointtopoint(d_rels, c_rels);
    counter = counter + 1;
    display(counter)
end

disp("Number of total points: ")
disp(Nframes);
disp("Number of rejected points: ")
disp(size(c_ks, 1) - size(c_rels, 1))
