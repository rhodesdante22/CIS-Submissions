function [triList, NTri] = constructTriList(probNum)
% Input surface file
addpath('input');
SurInfo = importdata(append('Problem', probNum, 'MeshFile.sur'), " ", 1);
Sur = SurInfo.data;
Nverts = double(string(SurInfo.textdata));
NTri = Sur(Nverts+1, 1);

% Extract Vertex "map", indices corresponding to the map
vertMap = Sur(1:Nverts, :);
vertDexes = Sur(Nverts+2:2:length(Sur), :); %skip adding the "neighbor" info

% Create a list of Surface mesh triangles 
triList = Triangle.empty(NTri, 0);
for row = 1:NTri
    dexes = vertDexes(row,:)+1; % for MATLAB indexing convention
    triList(row) = Triangle(vertMap(dexes(1), :), vertMap(dexes(2), :), vertMap(dexes(3), :));
end
end


